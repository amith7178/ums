<?php 
include('class/User.php');
$user = new User();
$errorMessage = '';
if(!empty($_POST['forgetpassword']) && $_POST['forgetpassword']) {
	$errorMessage =  $user->resetPassword();
}
include('include/header.php');
?>
<?php include('include/container.php');?>
<div class="container contact">	
	<div class="col-md-6">                    
		<div class="panel panel-info" >
			<div class="panel-heading" style="background:#337ab7;color:white;">
				<div class="panel-title">Forget Password</div>                        
			</div> 
			<div style="padding-top:30px" class="panel-body" >
				<?php if ($errorMessage != '') { ?>
					<div id="login-alert" class="alert alert-danger col-sm-12"><?php echo $errorMessage; ?></div>                            
				<?php } ?>
				<form id="loginform" class="form-horizontal" role="form" method="POST" action="">                                    
					<div style="margin-bottom: 25px" class="input-group">
						<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
						<input type="email" class="form-control" id="email" name="email"  placeholder="Email Address" required>                                        
					</div>				
					<div style="margin-top:10px" class="form-group">                               
						<div class="col-sm-12 controls">
						  <input type="submit" name="forgetpassword" value="Submit" class="btn btn-info" style="background:#337ab7;color:white;">						  
                                                  <label><a href="login.php">Login</a></label>
						</div>					
					</div>
				</form>   
			</div>                     
		</div>  
	</div>
</div>	
<?php include('include/footer.php');?>
