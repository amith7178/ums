<style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: #3f4d72;
  color: white;
  text-align: center;
}
</style>

<div class="footer">
  <p><b>Activity 07 - 2018mis019</b></p>
</div>
