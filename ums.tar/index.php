<?php 
include('class/User.php');
$user = new User();
$user->loginStatus();
include('include/header.php');
?>
<title><?php echo ucwords($_SESSION['name']); ?></title>
<?php include('include/container.php');?>
<div class="container contact">	
	<?php include('menu.php');?>
	<div class="table-responsive">	
	welcome <?php echo ucwords($_SESSION['name']); ?>
	</div>
</div>	
<?php include('include/footer.php');?>
